package com.gestao.endereco.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PaginaController {

    @GetMapping("/incluir-endereco")
    public String incluirEndereco() {
        return "incluir-endereco";
    }

    @GetMapping("/incluir-endereco-cliente")
    public String incluirEnderecoCliente() {
        return "incluir-endereco-cliente";
    }

    @GetMapping("/consultar-endereco")
    public String consultarEndereco() {
        return "consultar-endereco";
    }

    @GetMapping("/consultar-endereco-cliente")
    public String consultarEnderecoCliente() {
        return "consultar-endereco-cliente";
    }

    @GetMapping("/editar-endereco-cliente")
    public String editarEnderecoCliente() {
        return "editar-endereco-cliente";
    }

    @GetMapping("/editar-endereco")
    public String editarEndereco(){
        return "editar-endereco";
    }

    @GetMapping("/excluir-endereco")
    public String excluirEndereco(){
        return "excluir-endereco";
    }


}