package com.gestao.endereco.dto;

import lombok.Data;

@Data
public class CreateEnderecoDto {

    private String nomeCliente; //Usado pelo adm(digita o nome)

    private String cep;
    private String rua;
    private Integer numero;
    private String complemento;
    private String bairro;

    private String cidade;
    private String estado;

    private Boolean principal;

    private Long clienteId;//Usado pelo cliente(digita o id)

}