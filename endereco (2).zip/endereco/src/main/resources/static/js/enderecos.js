let idExcluir = null;

function abrirSucesso(){

    limparErros();

    let valido = true;

    const cep = document.getElementById("cep");
    const rua = document.getElementById("rua");
    const numero = document.getElementById("numero");
    const bairro = document.getElementById("bairro");
    const cidade = document.getElementById("cidade");
    const estado = document.getElementById("estado");




    if(cep.value === ""){

        document.getElementById("erroCep").innerText = "Campo obrigatório";

        cep.classList.add("input-erro");

        valido = false;
    }

    if(rua.value === ""){

        document.getElementById("erroRua").innerText = "Campo obrigatório";

        rua.classList.add("input-erro");

        valido = false;
    }

    if(numero.value === ""){

        document.getElementById("erroNumero").innerText = "Campo obrigatório";

        numero.classList.add("input-erro");

        valido = false;
    }

   if(bairro.value === ""){

       document.getElementById("erroBairro").innerText = "Campo obrigatório";

       bairro.classList.add("input-erro");

       valido = false;
   }

    if(cidade.value === ""){

        document.getElementById("erroCidade").innerText = "Campo obrigatório";

        cidade.classList.add("input-erro");

        valido = false;
    }

    if(estado.value === ""){

        document.getElementById("erroEstado").innerText = "Campo obrigatório";

        estado.classList.add("input-erro");

        valido = false;
    }

    if(!valido){
        return;
    }

    document.getElementById("modalSucesso").style.display = "flex";
}
function limparErros(){

    const erros = document.querySelectorAll(".erro");

    erros.forEach(erro => {
        erro.innerText = "";
    });

    const inputs = document.querySelectorAll("input");

    inputs.forEach(input => {
        input.classList.remove("input-erro");
    });
}

async function buscarCep(){

    let cep = document.getElementById("cep").value;

    cep = cep.replace(/\D/g, "");

    if(cep.length !== 8){
        return;
    }

    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);

    const dados = await resposta.json();


    document.getElementById("rua").value = dados.logradouro;
    document.getElementById("bairro").value = dados.bairro;
    document.getElementById("cidade").value = dados.localidade;
    document.getElementById("estado").value = dados.uf;
}

// Remove a mensagem de erro e a borda vermelha do campo
function limparErroCampo(inputId, erroId){


    // Pega o input pelo ID
    const input = document.getElementById(inputId);

    // Pega o span da mensagem de erro
    const erro = document.getElementById(erroId);

    // Remove a classe da borda vermelha
    input.classList.remove("input-erro");

     // Limpa a mensagem de erro
    erro.innerText = "";
}

function abrirSucessoExcluir(){

    document.getElementById("modalSucessoExcluir").style.display = "flex";
}

function fecharSucessoExcluir(){

    document.getElementById("modalSucessoExcluir").style.display = "none";

    window.location.href = "/consultar-endereco";
}

function fecharModalExcluir(){

    document.getElementById("modalExcluir").style.display = "none";
}

function abrirModalExcluir(id){

    idExcluir = id;

   document.getElementById("modalExcluir").style.display = "flex";
    }

async function excluirEndereco(){

    const response = await fetch(
        `http://localhost:8080/enderecos/${idExcluir}`,
        {
            method: "DELETE"
        }
    );

    if(response.ok){

        fecharModalExcluir();

        document.getElementById("modalSucessoExcluir").style.display = "flex";

        carregarEnderecos();

    }else{
        alert("Erro ao excluir endereço.");
    }
}

async function salvarEndereco() {

    limparErros();

        let valido = true;

        if(document.getElementById("cliente").value === ""){
                    document.getElementById("erroCliente").innerText = "Campo obrigatório";
                    document.getElementById("cliente").classList.add("input-erro");
                    valido = false;
                }

        if(document.getElementById("cep").value === ""){
            document.getElementById("erroCep").innerText = "Campo obrigatório";
            document.getElementById("cep").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("rua").value === ""){
            document.getElementById("erroRua").innerText = "Campo obrigatório";
            document.getElementById("rua").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("numero").value === ""){
            document.getElementById("erroNumero").innerText = "Campo obrigatório";
            document.getElementById("numero").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("bairro").value === ""){
            document.getElementById("erroBairro").innerText = "Campo obrigatório";
            document.getElementById("bairro").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("cidade").value === ""){
            document.getElementById("erroCidade").innerText = "Campo obrigatório";
            document.getElementById("cidade").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("estado").value === ""){
            document.getElementById("erroEstado").innerText = "Campo obrigatório";
            document.getElementById("estado").classList.add("input-erro");
            valido = false;
        }

        if(!valido){
            return;
        }

    const endereco = {
        clienteId: document.getElementById("clienteId").value || null,
        nomeCliente: document.getElementById("cliente").value,
        cep: document.getElementById("cep").value,
        rua: document.getElementById("rua").value,
        numero: document.getElementById("numero").value,
        complemento: document.getElementById("complemento").value,
        bairro: document.getElementById("bairro").value,
        cidade: document.getElementById("cidade").value,
        estado: document.getElementById("estado").value,
        principal: document.getElementById("principal").checked
    };

    const response = await fetch("http://localhost:8080/enderecos", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(endereco)
    });

    if (response.ok) {
        document.getElementById("modalSucesso").style.display = "flex";
    }
}

function cancelarEdicao() {
const params = new URLSearchParams(window.location.search);
const origem = params.get("origem");

    if (origem === "cliente") {

        window.location.href = "/consultar-endereco-cliente";

    } else {

        window.location.href = "/consultar-endereco";
    }
}
function fecharModal() {

    document.getElementById("modalSucesso").style.display = "none";

        const params = new URLSearchParams(window.location.search);
        const origem = params.get("origem");

        if (origem === "cliente") {

            window.location.href = "/consultar-endereco-cliente";

        } else {

            window.location.href = "/consultar-endereco";
        }
    }
async function carregarEnderecos() {


    const response = await fetch("http://localhost:8080/enderecos");
    const enderecos = await response.json();

    const tabela = document.getElementById("tabelaEnderecos");
    tabela.innerHTML = "";

    enderecos.forEach(end => {
    console.log(end);
        tabela.innerHTML += `
            <tr>
                <td>${end.id}</td>
                <td>${end.cliente.nome}</td>
                <td class="cep">${end.cep}</td>
                <td class="cep">${end.rua}</td>
                <td>${end.numero}</td>
                <td>${end.bairro}</td>
                <td>${end.cidade.nome}</td>
                <td>${end.cidade.estado}</td>
                <td>${end.principal ? "⭐" : ""}</td>
                <td>
                    <span onclick="editar(${end.id})">✏️</span>
                    <span onclick="abrirModalExcluir(${end.id})">🗑️</span>
                </td>
            </tr>
        `;
    });
}
function editar(id) {

    window.location.href = `/editar-endereco?id=${id}`;

}

async function carregarEnderecoParaEditar() {

    const params = new URLSearchParams(window.location.search);

    const id = params.get("id");

    const response = await fetch(`http://localhost:8080/enderecos/${id}`);

    const end = await response.json();

    document.getElementById("enderecoId").value = end.id;
    document.getElementById("clienteId").value = end.cliente.id;
    document.getElementById("cliente").value = end.cliente.nome;
    document.getElementById("cep").value = end.cep;
    document.getElementById("rua").value = end.rua;
    document.getElementById("numero").value = end.numero;
    document.getElementById("bairro").value = end.bairro;
    document.getElementById("cidade").value = end.cidade.nome;
    document.getElementById("estado").value = end.cidade.estado;
    document.getElementById("principal").checked = end.principal;
}
if (window.location.pathname.includes("editar-endereco")) {
    carregarEnderecoParaEditar();
}
async function editarEndereco() {

limparErros();

        let valido = true;

        if(document.getElementById("cliente").value === ""){
                    document.getElementById("erroCliente").innerText = "Campo obrigatório";
                    document.getElementById("cliente").classList.add("input-erro");
                    valido = false;
                }

        if(document.getElementById("cep").value === ""){
            document.getElementById("erroCep").innerText = "Campo obrigatório";
            document.getElementById("cep").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("rua").value === ""){
            document.getElementById("erroRua").innerText = "Campo obrigatório";
            document.getElementById("rua").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("numero").value === ""){
            document.getElementById("erroNumero").innerText = "Campo obrigatório";
            document.getElementById("numero").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("bairro").value === ""){
            document.getElementById("erroBairro").innerText = "Campo obrigatório";
            document.getElementById("bairro").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("cidade").value === ""){
            document.getElementById("erroCidade").innerText = "Campo obrigatório";
            document.getElementById("cidade").classList.add("input-erro");
            valido = false;
        }

        if(document.getElementById("estado").value === ""){
            document.getElementById("erroEstado").innerText = "Campo obrigatório";
            document.getElementById("estado").classList.add("input-erro");
            valido = false;
        }

        if(!valido){
            return;
        }

    const id = document.getElementById("enderecoId").value;

    const endereco = {
        clienteId: document.getElementById("clienteId").value || null,
        nomeCliente: document.getElementById("cliente").value,
        cep: document.getElementById("cep").value,
        rua: document.getElementById("rua").value,
        numero: document.getElementById("numero").value,
        complemento: document.getElementById("complemento").value,
        bairro: document.getElementById("bairro").value,
        cidade: document.getElementById("cidade").value,
        estado: document.getElementById("estado").value,
        principal: document.getElementById("principal").checked
    };

    const response = await fetch(
        `http://localhost:8080/enderecos/${id}`,
        {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(endereco)
        }
    );

    if (response.ok) {
         document.getElementById("modalSucesso").style.display = "flex";

    } else {
        alert("Erro ao atualizar endereço.");
    }
}

function filtrarEnderecos() {


    const cliente = document.getElementById("filtroCliente").value.toLowerCase();
    const cidade = document.getElementById("filtroCidade").value.toLowerCase();
    const estado = document.getElementById("filtroEstado").value.toLowerCase();
    const cep = document.getElementById("filtroCep").value.toLowerCase();

    const mensagem = document.getElementById("mensagemFiltro");

        if (
            cliente === "" &&
            cidade === "" &&
            estado === "" &&
            cep === ""
        ) {
            mensagem.innerText = "Preencha pelo menos um campo.";
            return;
        }

    let encontrou = false;

    const linhas = document.querySelectorAll("#tabelaEnderecos tr");

    linhas.forEach(linha => {

        const colunas = linha.querySelectorAll("td");

        const nomeCliente = colunas[1]?.innerText.toLowerCase() || "";
        const cepLinha = colunas[2]?.innerText.toLowerCase() || "";
        const cidadeLinha = colunas[6]?.innerText.toLowerCase() || "";
        const estadoLinha = colunas[7]?.innerText.toLowerCase() || "";

        const mostrar =
            nomeCliente.includes(cliente) &&
            cepLinha.includes(cep) &&
            cidadeLinha.includes(cidade) &&
            estadoLinha.includes(estado);


        linha.style.display = mostrar ? "" : "none";

        if (mostrar) {
                encontrou = true;
            }
    });

if (!encontrou) {
    mensagem.innerText = "Nenhum endereço encontrado.";
} else {
    mensagem.innerText = "";
}
}

function limparFiltros() {

    document.getElementById("filtroCliente").value = "";
    document.getElementById("filtroCidade").value = "";
    document.getElementById("filtroEstado").value = "";
    document.getElementById("filtroCep").value = "";

    const linhas = document.querySelectorAll("#tabelaEnderecos tr");

    linhas.forEach(linha => {
        linha.style.display = "";
    });
}

window.onload = carregarEnderecos;