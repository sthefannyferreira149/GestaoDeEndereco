// ─────────────────────────────────────────────
//  cliente.js  –  Endereços do cliente logado
// ─────────────────────────────────────────────

let idExcluirCliente = null;

// ── Utilitário: pega o ID do cliente logado ──────────────────────────────────
// Ajuste conforme sua autenticação: sessionStorage, cookie, meta tag, etc.
function getClienteId() {
    // Exemplo com sessionStorage:
    //   sessionStorage.setItem("clienteId", "5");  // defina isso no login
    //   return sessionStorage.getItem("clienteId");

    // Exemplo com meta tag no HTML:
    //   <meta name="clienteId" content="5">
    //   return document.querySelector('meta[name="clienteId"]').content;

    // Fallback temporário para testes (substitua pela implementação real):
    return 1;
}

// ── Carregar endereços do cliente ────────────────────────────────────────────
async function carregarEnderecosCliente() {

    const clienteId = getClienteId();

    const response = await fetch(
        `http://localhost:8080/enderecos/cliente/${clienteId}`
    );

    const enderecos = await response.json();

    renderizarTabela(enderecos);
}

// ── Renderizar tabela ─────────────────────────────────────────────────────────
function renderizarTabela(enderecos) {

    const tabela = document.getElementById("tabelaEnderecos");
    tabela.innerHTML = "";

    enderecos.forEach(end => {

        tabela.innerHTML += `
            <tr>
                <td>${end.cep}</td>
                <td>${end.rua}</td>
                <td>${end.numero}</td>
                <td>${end.bairro}</td>
                <td>${end.cidade.nome}</td>
                <td>${end.cidade.estado}</td>
                <td>${end.principal ? "⭐" : ""}</td>
                <td>
                    <span onclick="editarCliente(${end.id})" title="Editar">✏️</span>
                    <span onclick="abrirModalExcluirCliente(${end.id})" title="Excluir">🗑️</span>
                </td>
            </tr>
        `;
    });
}

// ── Redirecionar para edição passando origem=cliente ─────────────────────────
//    O editar-endereco.html usa cancelarEdicao() / fecharModal() que leem
//    o parâmetro "origem" e redirecionam para a tela certa.
function editarCliente(id) {
   window.location.href = `/editar-endereco?id=${id}&origem=cliente`;
}

// ── Modais de exclusão ────────────────────────────────────────────────────────
function abrirModalExcluirCliente(id) {
    idExcluirCliente = id;
    document.getElementById("modalExcluir").style.display = "flex";
}

function fecharModalExcluirCliente() {
    document.getElementById("modalExcluir").style.display = "none";
}

async function excluirEnderecoCliente() {

    const response = await fetch(
        `http://localhost:8080/enderecos/${idExcluirCliente}`,
        { method: "DELETE" }
    );

    if (response.ok) {

        fecharModalExcluirCliente();

        document.getElementById("modalSucessoExcluir").style.display = "flex";

    } else {
        alert("Erro ao excluir endereço.");
    }
}

function fecharSucessoExcluirCliente() {

    document.getElementById("modalSucessoExcluir").style.display = "none";

    carregarEnderecosCliente();   // recarrega a tabela sem redirecionar
}

// ── Salvar novo endereço (tela de cadastro do cliente) ────────────────────────
async function salvarEnderecoCliente() {

    limparErrosCliente();

    let valido = true;

    const campos = ["cep", "rua", "numero", "bairro", "cidade", "estado"];
    const erros  = ["erroCep", "erroRua", "erroNumero", "erroBairro", "erroCidade", "erroEstado"];

    campos.forEach((campo, i) => {
        if (document.getElementById(campo).value === "") {
            document.getElementById(erros[i]).innerText = "Campo obrigatório";
            document.getElementById(campo).classList.add("input-erro");
            valido = false;
        }
    });

    if (!valido) return;

    const clienteId = getClienteId();

    const endereco = {
        clienteId: clienteId,
        cep:        document.getElementById("cep").value,
        rua:        document.getElementById("rua").value,
        numero:     document.getElementById("numero").value,
        complemento:document.getElementById("complemento").value,
        bairro:     document.getElementById("bairro").value,
        cidade:     document.getElementById("cidade").value,
        estado:     document.getElementById("estado").value,
        principal:  document.getElementById("principal").checked
    };

    const response = await fetch("http://localhost:8080/enderecos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(endereco)
    });

    if (response.ok) {
        document.getElementById("modalSucesso").style.display = "flex";
    } else {
        alert("Erro ao salvar endereço.");
    }
}

// Fecha modal de sucesso do cadastro e volta para consulta
function fecharModalCliente() {
    document.getElementById("modalSucesso").style.display = "none";
    window.location.href = "/consultar-endereco-cliente";
}

// ── Busca/filtro local na tabela ──────────────────────────────────────────────
function buscarEnderecoCliente() {

    const termo = document.getElementById("buscaCliente").value.toLowerCase();
    const linhas = document.querySelectorAll("#tabelaEnderecos tr");
    const mensagem = document.getElementById("mensagemFiltroCliente");

    let encontrou = false;

    linhas.forEach(linha => {
        const texto = linha.innerText.toLowerCase();
        const mostrar = texto.includes(termo);
        linha.style.display = mostrar ? "" : "none";
        if (mostrar) encontrou = true;
    });

    mensagem.innerText = encontrou ? "" : "Nenhum endereço encontrado.";
}

function limparBuscaCliente() {
    document.getElementById("buscaCliente").value = "";
    document.querySelectorAll("#tabelaEnderecos tr").forEach(tr => {
        tr.style.display = "";
    });
    const mensagem = document.getElementById("mensagemFiltroCliente");
    if (mensagem) mensagem.innerText = "";
}

// ── Limpeza de erros de formulário ───────────────────────────────────────────
function limparErrosCliente() {
    document.querySelectorAll(".erro").forEach(e => e.innerText = "");
    document.querySelectorAll("input").forEach(i => i.classList.remove("input-erro"));
}
async function buscarCep(){

    let cep = document.getElementById("cep").value;

    cep = cep.replace(/\D/g, "");

    if(cep.length !== 8){
        return;
    }

    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);

    const dados = await resposta.json();

    document.getElementById("rua").value = dados.logradouro;
    document.getElementById("bairro").value = dados.bairro;
    document.getElementById("cidade").value = dados.localidade;
    document.getElementById("estado").value = dados.uf;
}
function limparErroCampo(inputId, erroId){

    const input = document.getElementById(inputId);

    const erro = document.getElementById(erroId);

    input.classList.remove("input-erro");

    erro.innerText = "";
}

window.onload = function () {

    if (document.getElementById("tabelaEnderecos")) {
        carregarEnderecosCliente();
    }
};