package com.gestao.endereco.model;

import jakarta.persistence.*;
import lombok.Data; // Substitui todos os getters e setters

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "endereco")
public class Endereco {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String rua;
    private Integer numero;
    private String cep;
    private String bairro;
    private String complemento;

    @Column(nullable = false)
    private Boolean principal;

    @Column(name = "creation_timestamp")
    private LocalDateTime creationTimestamp;

    @Column(name = "update_timestamp")
    private LocalDateTime updateTimestamp;

    // relacionamento com cidade (OBRIGATÓRIO)
    @ManyToOne
    @JoinColumn(name = "id_cidade", nullable = false)
    private Cidade cidade;

    // relacionamento com cliente (OBRIGATÓRIO)
    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;
}